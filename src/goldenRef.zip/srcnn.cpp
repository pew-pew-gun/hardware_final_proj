#include "srcnn.h"
#include <math.h>

void srcnn(ftmap_t input_ftmap[N0][H][W],
           param_t conv1_weights[N1][N0][F1][F1],
           param_t conv1_biases[N1],
           param_t conv2_weights[N2][N1][F2][F2],
           param_t conv2_biases[N2],
           param_t conv3_weights[N3][N2][F3][F3],
           param_t conv3_biases[N3],
           ftmap_t output_ftmap[N3][H][W])
{

	/* input_ftmap[input_feature][height][width]		(input feature map)
	 * convl_weights[output_feature][input_feature][kernel_height][kernel_width]
	 * 													(performing the convolution)
	 * convl_biases[output_feature]						(sum this onto output feature)
	 * output_ftmap[output_feature][height][width]	    (output feature map) */


    // Implement end-to-end SRCNN here
	static ftmap_t convLayer1[N1][H][W]; // [output_feature][height][width (of each feature map)]
	static ftmap_t convLayer2[N2][H][W];

	// 1. conv1 (first layer)
	// [build up output feature map pixel by pixel]
	for (int of=0; of<N1; of++) {							// output feature (channel)
		for (int oh=0; oh<H; oh++) {						// output height
			for (int ow=0; ow<W; ow++) {					// output width
				// Add bias for each output feature map
				float conv1 = conv1_biases[of];
				for (int ic=0; ic<N0; ic++) { 				// input feature (channel)
					// Kernel computation:
					for (int kh=0; kh<F1; kh++) { 			// kernel height
						for (int kw=0; kw<F1; kw++) { 		// kernel width
							// 1. Apply 'same' padding to input feature map by clamping indices
							int pad = F1/2;
							int ih = fmin(fmax(oh+kh-pad,0), H-1);
							int iw = fmin(fmax(ow+kw-pad,0), W-1);

							// MAC
							conv1 += conv1_weights[of][ic][kh][kw] * input_ftmap[ic][ih][iw]; // stride 1, same padding
						}

					}
				}
				// 4. ReLU
				convLayer1[of][oh][ow] = fmaxf(0, conv1);
			}
		}
	}

	/* convLayer1[input_feature][height][width]			(input feature map)
	 * conv2_weights[output_feature][input_feature][kernel_height][kernel_width]
	 * 													(performing the convolution)
	 * conv2_biases[output_feature]						(sum this onto output feature)
	 * convLayer2[output_feature][height][width]	    (output feature map) */

//	   param_t conv2_weights[N2][N1][F2][F2],
//	   param_t conv2_biases[N2],

	// 2. conv2 (second layer)
	// [build up output feature map pixel by pixel]
	for (int of=0; of<N2; of++) {							// output feature (channel)
		for (int oh=0; oh<H; oh++) {						// output height
			for (int ow=0; ow<W; ow++) {					// output width
				// Add bias for each output feature map
				float conv = conv2_biases[of];
				for (int ic=0; ic<N1; ic++) { 				// input feature (channel)
					// Kernel computation:
					for (int kh=0; kh<F2; kh++) { 			// kernel height
						for (int kw=0; kw<F2; kw++) { 		// kernel width
							// 1. Apply 'same' padding to input feature map by clamping indices
							int pad = F2/2;
							int ih = fmin(fmax(oh+kh-pad,0), H-1);
							int iw = fmin(fmax(ow+kw-pad,0), W-1);

							// MAC
							conv += conv2_weights[of][ic][kh][kw] * convLayer1[ic][ih][iw]; // stride 1, same padding
						}

					}
				}
				// 4. ReLU
				convLayer2[of][oh][ow] = fmaxf(0, conv);
			}
		}
	}


	// 3. conv3 (third layer, no ReLU)
	// [build up output feature map pixel by pixel]
	for (int of=0; of<N3; of++) {							// output feature (channel)
		for (int oh=0; oh<H; oh++) {						// output height
			for (int ow=0; ow<W; ow++) {					// output width
				// Add bias for each output feature map
				float conv = conv3_biases[of];
				for (int ic=0; ic<N2; ic++) { 				// input feature (channel)
					// Kernel computation:
					for (int kh=0; kh<F3; kh++) { 			// kernel height
						for (int kw=0; kw<F3; kw++) { 		// kernel width
							// 1. Apply 'same' padding to input feature map by clamping indices
							int pad = F3/2;
							int ih = fmin(fmax(oh+kh-pad,0), H-1);
							int iw = fmin(fmax(ow+kw-pad,0), W-1);

							// MAC
							conv += conv3_weights[of][ic][kh][kw] * convLayer2[ic][ih][iw]; // stride 1, same padding
						}

					}
				}
			output_ftmap[of][oh][ow] = conv;
			}
		}
	}

}
